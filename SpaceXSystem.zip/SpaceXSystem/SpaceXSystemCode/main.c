#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Lib.h"


int main()
{
    readUserData();
    mainMenu();
    return 0;
}
